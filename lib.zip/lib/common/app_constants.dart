class AppConstants{
  static const String onboardingKey='onboardingSeen';
}